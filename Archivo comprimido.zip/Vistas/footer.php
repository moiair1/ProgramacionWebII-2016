    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="../Resources/js/jquery-1.11.3.min"></script>
 
    <!-- Include all compiled plugins (below), or include individual files as needed -->

<script src="../Resources/js/bootstrap.min.js"></script>