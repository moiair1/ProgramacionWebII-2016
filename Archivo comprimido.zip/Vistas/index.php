<?php





?>

<html>
<head>
<meta http-equiv="Refresh" content="5;url=listado_clientes.php">
</head>